import 'package:flutter/material.dart';

class AppColors {
  const AppColors._();

  static const Color orangeColor = Color(0xFFC6A664);
  static const Color greenVIP = Color(0xFF43A047);
  static const Color blueVIP = Color(0xFF1E88E5);
}
